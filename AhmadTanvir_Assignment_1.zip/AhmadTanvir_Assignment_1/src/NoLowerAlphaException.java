/**
 * NoLowerAlphaException Class
 * @author Tanvir
 *
 */
public class NoLowerAlphaException extends Exception{
	private static final long serialVersionUID = 1L;

	/** 
	 * Constructs a NoLowerAlphaException with a default error message.
	 */
	public NoLowerAlphaException() {
		super("The password must contain at least one lowercase alphabetic character");
	}
}
