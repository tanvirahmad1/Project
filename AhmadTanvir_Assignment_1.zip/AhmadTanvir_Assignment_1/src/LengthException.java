/**
 * LengthException Class
 * @author Tanvir 
 *
 */
public class LengthException extends Exception {
	private static final long serialVersionUID = 1L;

	/** 
	 * Constructs a LengthException with a default error message.
	 */
	public LengthException() {	
		super("The password must be at least 6 characters long");
	}
}
