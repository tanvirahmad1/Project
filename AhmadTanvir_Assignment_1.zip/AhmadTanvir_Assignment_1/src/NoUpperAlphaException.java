/**
 * NoUpperAlphaException Class
 * @author 
 *
 */
public class NoUpperAlphaException extends Exception{
	private static final long serialVersionUID = 1L;

	/** 
	 * Constructs a NoUpperAlphaException with a default error message.
	 */

	public NoUpperAlphaException() {
		super("The password must contain at least one uppercase alphabetic character");
	}
	
}
