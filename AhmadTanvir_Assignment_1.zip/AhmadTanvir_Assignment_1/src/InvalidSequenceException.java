/**
 * InvalidSequenceException Class
 * @author Tanvir
 *
 */
public class InvalidSequenceException extends Exception{
	private static final long serialVersionUID = 1L;

	/** 
	 * Constructs an InvalidSequenceException with a default error message.
	 */
	public InvalidSequenceException() {
		super("The password cannot contain more than two of the same character in sequence");
	}
}
