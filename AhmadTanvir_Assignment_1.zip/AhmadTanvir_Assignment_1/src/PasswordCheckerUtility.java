import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
/**
 * PasswordCheckerUtility Class
 * @author Tanvir 
 *
 */
public final class PasswordCheckerUtility {

	/** 
	 * Checks if the string length is greater than 6 characters.
	 * @param pass the string to check
	 * @return true if length > 6, otherwise throws LengthException
	 * @throws LengthException if length is not greater than 6
	 */
	private static boolean checkLength(String pass) throws LengthException {
		if (pass.length()<6) 
			throw new LengthException();
		else
			return true;
	}

	/** 
	 * Checks if the string contains at least one uppercase character.
	 * @param pass the string to check
	 * @return true if there's at least one uppercase character, otherwise throws NoUpperAlphaException
	 * @throws NoUpperAlphaException if no uppercase character is found
	 */

	private static boolean hasUpperAlpha(String pass) throws NoUpperAlphaException {
		if(pass.equals(pass.toLowerCase())) 
			throw new NoUpperAlphaException();
		else
			return true;
			
	}
	/** 
	 * Checks if the string contains at least one lowercase character.
	 * @param pass the string to check
	 * @return true if there's at least one lowercase character, otherwise throws NoLowerAlphaException
	 * @throws NoLowerAlphaException if no lowercase character is found
	 */

	private static boolean hasLowerAlpha(String pass) throws NoLowerAlphaException {
		if(pass.equals(pass.toUpperCase())) 
			throw new NoLowerAlphaException();
		else
			return true;

	}
	
	/** 
	 * Checks if the string contains at least one digit.
	 * @param pass the string to check
	 * @return true if there's a digit, throws NoDigitException otherwise
	 * @throws NoDigitException if no digit is found
	 */
	private static boolean hasDigit(String pass) throws NoDigitException {
		char[] pass2=pass.toCharArray();
		int count=0;
		for(int i=0;i<pass2.length;i++) {
			if(Character.isDigit(pass2[i])) {
				count++;
			}
		}
		if(count==0) {
			throw new NoDigitException();
		}
		else {
			return true;
		}

	}
	
	/** 
	 * Checks if the string contains at least one special character.
	 * @param pass the string to check
	 * @return true if there's a special character, throws NoSpecialCharacterException otherwise
	 * @throws NoSpecialCharacterException if no special character is found
	 */

	private static boolean hasSpecialChar(String pass) throws NoSpecialCharacterException {
		String reg="[a-zA-Z0-9]*";
		Pattern pat=Pattern.compile(reg);
		Matcher mat=pat.matcher(pass);
		
		if(mat.matches()) {
			throw new NoSpecialCharacterException();
		}
		else {
			return true;
		}
		
	}
	
	/**
	 * Method to check if a character doesn't repeat itself 3 or more times consecutively
	 * @param pass string to check if no character repeats 3 or more time consecutively
	 * @return true if no character repeats 3 or more time consecutively, throws InvalidSequenceException otherwise
	 * @throws InvalidSequenceException
	 */
	private static boolean isValidSequence(String pass) throws InvalidSequenceException {		

		boolean isValid=true;
		for (int i=0;i<=pass.length()-2;i++) { 
			if(pass.charAt(i)==pass.charAt(i+1)) {
				if (pass.charAt(i)==pass.charAt(i+2)) {
					isValid=false;
					throw new InvalidSequenceException();
				}
				
			}
		}
		return isValid;
		
	}
	
	/** 
	 * Checks if a string meets all the criteria for a valid password.
	 * @param passwordString the string to check for validity
	 * @return true if the string is a valid password, false otherwise
	 * @throws LengthException if the password length is invalid
	 * @throws NoDigitException if the password lacks a digit
	 * @throws NoUpperAlphaException if the password lacks an uppercase letter
	 * @throws NoLowerAlphaException if the password lacks a lowercase letter
	 * @throws NoSpecialCharacterException if the password lacks a special character
	 * @throws InvalidSequenceException if the password contains an invalid sequence
	 */
	public static boolean isValidPassword(String passwordString) 
	        throws LengthException, NoDigitException, NoUpperAlphaException, 
	               NoLowerAlphaException, NoSpecialCharacterException, InvalidSequenceException {
	    
	    boolean len = false, up = false, low = false, dig = false, spec = false, seq = false, val = true;    
	    
	    try {
	        len = checkLength(passwordString);
	        up = hasUpperAlpha(passwordString);
	        low = hasLowerAlpha(passwordString);
	        dig = hasDigit(passwordString);
	        spec = hasSpecialChar(passwordString);
	        seq = isValidSequence(passwordString);
	    } finally {
	        if (len && up && low && dig && spec && seq) {
	            val = true;
	        } else {
	            val = false;
	        }
	    }
	    return val;
	}

	/** 
	 * Checks if a string is a weak password (length between 6 and 9 characters).
	 * @param passwordString the string to check
	 * @return true if the password is weak, false otherwise
	 * @throws WeakPasswordException if the password is weak
	 */
	public static boolean isWeakPassword(String passwordString) throws WeakPasswordException{
		boolean weak=false;
		if(passwordString.length()>=6 && passwordString.length()<=9) {
			weak=true;
		}
		return weak;
	}
	
	/** 
	 * Finds all invalid passwords from a list of passwords.
	 * @param passwords the list of passwords to check
	 * @return an ArrayList of invalid passwords with corresponding error messages
	 */
	public static ArrayList<String> getInvalidPasswords(ArrayList<String> passwords) {
	    ArrayList<String> invalidPasswords = new ArrayList<>();
	    
	    for (String password : passwords) {    
	        try {
	            if (!isValidPassword(password)) {
	                invalidPasswords.add(password);  // Add invalid password to list
	            }
	        } catch (Exception e) {
	            invalidPasswords.add(password + " " + e.getMessage());  // Add password with error message
	        }
	    }
	    
	    return invalidPasswords;        
	}


}
