/**
 * UnmatchedException Class
 * @author Tanvir
 *
 */
public class UnmatchedException extends Exception {
	
	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor of UnmatchedException
	 * Assigns appropriate message to print in case exception happens
	 */
	public UnmatchedException() {
		super("The passwords do not match");
	}
}
