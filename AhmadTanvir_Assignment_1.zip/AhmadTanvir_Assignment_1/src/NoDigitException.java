/**
 * NoDigitException
 * @author Tanvir
 *
 */
public class NoDigitException extends Exception{
	private static final long serialVersionUID = 1L;

	/** 
	 * Constructs a NoDigitException with a default error message.
	 */
	public NoDigitException() {
	super("The password must contain at least one digit");
	}
}
