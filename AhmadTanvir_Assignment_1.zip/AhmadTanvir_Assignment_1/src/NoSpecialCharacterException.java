/**
 * NoSpecialCharacterException
 * @author Tanvir
 *
 */
public class NoSpecialCharacterException extends Exception{
	private static final long serialVersionUID = 1L;
	
	/** 
	 * Constructs a NoSpecialCharacterException with a default error message.
	 */
	public NoSpecialCharacterException() {
		super("The password must contain at least one special character");
	}
}
